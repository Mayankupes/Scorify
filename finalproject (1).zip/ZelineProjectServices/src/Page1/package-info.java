package Page1;
//this page is our home page from this page we can go to page2 and page 3
//page 2 will be user login
//page 3 will be home page for user login