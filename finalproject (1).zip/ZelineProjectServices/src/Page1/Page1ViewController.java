package Page1;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import Dependies_Zeline.MySQL_Connector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

public class Page1ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField username;

    @FXML
    private TextField password;


    @FXML
    void adminlogin(ActionEvent event) {
        java.sql.Connection con;
        con= MySQL_Connector.getConnection();
        java.sql.PreparedStatement pst;

        try {

            pst=con.prepareStatement(" select * from user where email=?");
            pst.setString(1,username.getText());

            ResultSet res=pst.executeQuery();
            boolean count=false;
            while(res.next()) {
                count=true;
                String PASS=res.getString("password");

                if(PASS.equals(password.getText())) {
                    System.out.println("LOGIN SUCCESSFUL");
                    javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Page7/Page7Vieww.fxml"));
                    //OR
                    //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
                    javafx.scene.Scene scene = new javafx.scene.Scene(root);
                    javafx.stage.Stage stage=new javafx.stage.Stage();
                    stage.setScene(scene);
                    stage.show();
                }
                else {
                    System.out.println("Incorrect credientials\n");
                    showMsg("Incorrect details");
                }

                //pst.executeUpdate();
                showMsg("Saved!");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }


    }

    void showMsg(String msg) {
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Ant Colony Algo Says:");
        alert.setHeaderText("Result Updated");
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    void close(ActionEvent event) {
    System.exit(1);
    }

    @FXML
    void userlogin(ActionEvent event) throws IOException {
        javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Page2/Page2View.fxml"));
        //OR
        //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        javafx.stage.Stage stage=new javafx.stage.Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void initialize() {
        assert username != null : "fx:id=\"username\" was not injected: check your FXML file 'Page1View.fxml'.";
        assert password != null : "fx:id=\"password\" was not injected: check your FXML file 'Page1View.fxml'.";

    }
}
