
package Page3;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

public class Page3ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void back(ActionEvent event) throws IOException {
        javafx.scene.Parent root= FXMLLoader.load(getClass().getResource("/Page1/Page1Viw.fxml"));
        //OR
        //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        javafx.stage.Stage stage=new javafx.stage.Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void close(ActionEvent event) {
    System.exit(1);
    }

    @FXML
    void info(ActionEvent event) throws IOException {
        javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Page4/Page4Viw.fxml"));
        //OR
        //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        javafx.stage.Stage stage=new javafx.stage.Stage();
        stage.setScene(scene);
        stage.show();
    }
    //eska name live hai glti se login likh liya
    @FXML
    void login(ActionEvent event) throws IOException {
        javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Page5/Page5View.fxml"));
        //OR
        //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        javafx.stage.Stage stage=new javafx.stage.Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void scorecard(ActionEvent event) throws IOException {
        javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Page6/Page6View.fxml"));
        //OR
        //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        javafx.stage.Stage stage=new javafx.stage.Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void initialize() {

    }
}

//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml")); 
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/