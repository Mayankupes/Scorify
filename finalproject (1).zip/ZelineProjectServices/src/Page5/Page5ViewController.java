package Page5;


import java.net.URL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import Dependies_Zeline.MySQL_Connector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;

public class Page5ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label run;

    @FXML
    private Label wicket;

    @FXML
    private Label target;

    @FXML
    private Label crr;

    @FXML
    private Label over;

    @FXML
    private Label req;

    @FXML
    private Label battera;

    @FXML
    private Label batterb;

    @FXML
    private Label ra;

    @FXML
    private Label ba;

    @FXML
    private Label foura;

    @FXML
    private Label sixa;

    @FXML
    private Label sra;

    @FXML
    private Label rb;

    @FXML
    private Label bb;

    @FXML
    private Label fourb;

    @FXML
    private Label sixb;

    @FXML
    private Label srb;

    @FXML
    private Label boller;

    @FXML
    private Label bollero;

    @FXML
    private Label bollerm;

    @FXML
    private Label bollerr;

    @FXML
    private Label bollerw;

    @FXML
    private Label bollerer;

    @FXML
    private Label team;

    @FXML
    private ComboBox<String> combobox;

    @FXML
    void close(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void show(ActionEvent event) {
        String teamfx=combobox.getSelectionModel().getSelectedItem();
        java.sql.Connection con;
        con=MySQL_Connector.getConnection();
        java.sql.PreparedStatement pst;
        System.out.println(teamfx);
        try {

            pst=con.prepareStatement("select * from live where team_a=?");
            pst.setString(1,teamfx);
            ResultSet res=pst.executeQuery();
            boolean count=false;
            while(res.next()) {
                count=true;
                String team_=res.getString("team_a");
                String run_=res.getString("run");
                String wicket_=res.getString("wicket");
                String over_=res.getString("over");
                String target_=res.getString("target");
                String crr_=res.getString("crr");
                String req_=res.getString("req");

                String bat_a=res.getString("batter_a");
                String r_a=res.getString("r_a");
                String b_a=res.getString("b_a");
                String four_a=res.getString("4_a");
                String six_a=res.getString("6_a");
                String sr_a=res.getString("sr_a");

                String bat_b=res.getString("batter_b");
                String r_b=res.getString("r_b");
                String b_b=res.getString("b_b");
                String four_b=res.getString("4_b");
                String six_b=res.getString("6_b");
                String sr_b=res.getString("sr_b");

                String boller_=res.getString("boller");
                String o_=res.getString("O");
                String m_=res.getString("m");
                String r_=res.getString("r");
                String w_=res.getString("w");
                String er_=res.getString("er");


                team.setText(team_);
                run.setText(run_);
                wicket.setText(wicket_);
                over.setText(over_);
                target.setText(target_);
                crr.setText(crr_);
                req.setText(req_);

                battera.setText(bat_a);
                ra.setText(r_a);
                ba.setText(b_a);
                foura.setText(four_a);
                sixa.setText(six_a);
                sra.setText(sr_a);

                batterb.setText(bat_b);
                rb.setText(r_b);
                bb.setText(b_b);
                fourb.setText(four_b);
                sixb.setText(six_b);
                srb.setText(sr_b);

                boller.setText(boller_);
                bollero.setText(o_);
                bollerm.setText(m_);
                bollerr.setText(r_);
                bollerw.setText(w_);
                bollerer.setText(er_);

                //pst.executeUpdate();
                //showMsg("Saved!");
            }
        }

        catch (Exception e) {
            showMsg("Team Not Found!");
            e.printStackTrace();


        }
    }
    void showMsg(String msg) {
        Alert alert=new Alert(AlertType.INFORMATION);
        alert.setTitle("Cricket Project:");
        alert.setHeaderText("Your details make:");
        alert.setContentText(msg);
        alert.showAndWait();
    }
    java.sql.Connection con;

    @FXML
    void initialize() {
        assert run != null : "fx:id=\"run\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert wicket != null : "fx:id=\"wicket\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert target != null : "fx:id=\"target\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert crr != null : "fx:id=\"crr\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert over != null : "fx:id=\"over\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert req != null : "fx:id=\"req\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert battera != null : "fx:id=\"battera\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert batterb != null : "fx:id=\"batterb\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert ra != null : "fx:id=\"ra\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert ba != null : "fx:id=\"ba\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert foura != null : "fx:id=\"foura\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert sixa != null : "fx:id=\"sixa\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert sra != null : "fx:id=\"sra\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert rb != null : "fx:id=\"rb\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert bb != null : "fx:id=\"bb\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert fourb != null : "fx:id=\"fourb\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert sixb != null : "fx:id=\"sixb\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert srb != null : "fx:id=\"srb\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert boller != null : "fx:id=\"boller\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert bollero != null : "fx:id=\"bollero\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert bollerm != null : "fx:id=\"bollerm\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert bollerr != null : "fx:id=\"bollerr\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert bollerw != null : "fx:id=\"bollerw\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert bollerer != null : "fx:id=\"bollerer\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert team != null : "fx:id=\"team\" was not injected: check your FXML file 'Page9View.fxml'.";
        assert combobox != null : "fx:id=\"combobox\" was not injected: check your FXML file 'Page9View.fxml'.";
        ArrayList<String> ary=new ArrayList<String>(Arrays.asList("india"));
        combobox.getItems().addAll(ary);

    }
}

//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml"));
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/
//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml")); 
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/