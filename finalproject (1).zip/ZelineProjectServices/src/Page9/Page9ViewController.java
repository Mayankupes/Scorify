package Page9;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import Dependies_Zeline.MySQL_Connector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class Page9ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> combobox;

    @FXML
    private TextField teams;

    @FXML
    private TextField run;

    @FXML
    private TextField wicket;

    @FXML
    private TextField over;

    @FXML
    private TextField target;

    @FXML
    private TextField crr;

    @FXML
    private TextField req;

    @FXML
    private TextField battera;

    @FXML
    private TextField batterb;

    @FXML
    private TextField baller;

    @FXML
    private TextField ra;

    @FXML
    private TextField rb;

    @FXML
    private TextField ba;

    @FXML
    private TextField bb;

    @FXML
    private TextField foura;

    @FXML
    private TextField fourb;

    @FXML
    private TextField sixa;

    @FXML
    private TextField sixb;

    @FXML
    private TextField ballm;

    @FXML
    private TextField ballr;

    @FXML
    private TextField ballerw;

    @FXML
    private TextField ballerer;


    @FXML
    private TextField SCOREA;

    @FXML
    private TextField SRB;

    @FXML
    private TextField BALLO;

    @FXML
    private TextField teams1;


    @FXML
    void close(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void upload(ActionEvent event) {
        java.sql.Connection con;
        con=MySQL_Connector.getConnection();
        java.sql.PreparedStatement pst;

        try {
            String teamfx=combobox.getSelectionModel().getSelectedItem();
            pst=con.prepareStatement("insert into live values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, teamfx);
            pst.setString(2, teams.getText());
            pst.setString(3, teams1.getText());
            pst.setString(4, run.getText());
            pst.setString(5, wicket.getText());
            pst.setString(6, over.getText());
            pst.setString(7, target.getText());
            pst.setString(8, crr.getText());
            pst.setString(9, req.getText());
            pst.setString(10,battera.getText());
            pst.setString(11,ra.getText());
            pst.setString(12,ba.getText());
            pst.setString(13,foura.getText());
            pst.setString(14,sixa.getText());
            pst.setString(15,SCOREA.getText());
            pst.setString(16,batterb.getText());
            pst.setString(17,rb.getText());
            pst.setString(18,bb.getText());
            pst.setString(19,fourb.getText());
            pst.setString(20,sixb.getText());
            pst.setString(21,SRB.getText());
            pst.setString(22,baller.getText());
            pst.setString(23,BALLO.getText());
            pst.setString(24,ballm.getText());
            pst.setString(25,ballr.getText());
            pst.setString(26,ballerw.getText());
            pst.setString(27,ballerer.getText());
            pst.executeUpdate();
            showMsg("Saved!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    void showMsg(String msg) {
        Alert alert=new Alert(AlertType.INFORMATION);
        alert.setTitle("Admin Panel Says:");
        alert.setHeaderText("Match Uploaded");
        alert.setContentText(msg);
        alert.showAndWait();

    }
    @FXML
    void initialize() {
        assert combobox != null : "fx:id=\"combobox\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert teams != null : "fx:id=\"teams\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert run != null : "fx:id=\"run\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert wicket != null : "fx:id=\"wicket\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert over != null : "fx:id=\"over\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert target != null : "fx:id=\"target\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert crr != null : "fx:id=\"crr\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert req != null : "fx:id=\"req\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert battera != null : "fx:id=\"battera\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert batterb != null : "fx:id=\"batterb\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert baller != null : "fx:id=\"baller\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert ra != null : "fx:id=\"ra\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert rb != null : "fx:id=\"rb\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert ba != null : "fx:id=\"ba\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert bb != null : "fx:id=\"bb\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert foura != null : "fx:id=\"foura\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert fourb != null : "fx:id=\"fourb\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert sixa != null : "fx:id=\"sixa\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert sixb != null : "fx:id=\"sixb\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert ballm != null : "fx:id=\"ballm\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert ballr != null : "fx:id=\"ballr\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert ballerw != null : "fx:id=\"ballerw\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert ballerer != null : "fx:id=\"ballerer\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert SCOREA != null : "fx:id=\"SCOREA\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert SRB != null : "fx:id=\"SRB\" was not injected: check your FXML file 'Page3View.fxml'.";
        assert BALLO != null : "fx:id=\"BALLO\" was not injected: check your FXML file 'Page3View.fxml'.";

        ArrayList<String> ary=new ArrayList<String>(Arrays.asList("india vs pakisthan"));
        combobox.getItems().addAll(ary);

    }
}



//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml"));
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/
//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml")); 
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/