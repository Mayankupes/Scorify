package Page4;


import java.net.URL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import Dependies_Zeline.MySQL_Connector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;

public class Page4ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label match;

    @FXML
    private Label overs;



    @FXML
    private Label ball;

    @FXML
    private Label toss;

    @FXML
    private Label offtobat;


    @FXML
    private Label date;

    @FXML
    private Label matchloc;

    @FXML
    private ComboBox<String> combobox;

    @FXML
    void close(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void show(ActionEvent event) {

        String teamfx=combobox.getSelectionModel().getSelectedItem();
        java.sql.Connection con;
        con=MySQL_Connector.getConnection();
        java.sql.PreparedStatement pst;
        System.out.println(teamfx);
        try {

            pst=con.prepareStatement(" select * from info where teams=?");
            pst.setString(1,teamfx);
            ResultSet res=pst.executeQuery();
            boolean count=false;
            while(res.next()) {
                count=true;
                String match_type=res.getString("match_type");
                String over=res.getString("overs");
                String date_time=res.getString("date_time");
                String venu=res.getString("venue");
                String ball_type=res.getString("ball_type");
                String tos=res.getString("toss");
                String off_to_bat=res.getString("off_to_bat");
                match.setText(match_type);
                overs.setText(over);
                date.setText(date_time);
                ball.setText(ball_type);
                toss.setText(tos);
                offtobat.setText(off_to_bat);
                matchloc.setText(venu);
                //pst.executeUpdate();
                //showMsg("Saved!");
            }
        }

        catch (Exception e) {
            showMsg("Team Not Found!");
            e.printStackTrace();


        }
    }
    void showMsg(String msg) {
        Alert alert=new Alert(AlertType.INFORMATION);
        alert.setTitle("Cricket Project:");
        alert.setHeaderText("Your details make:");
        alert.setContentText(msg);
        alert.showAndWait();
    }
    java.sql.Connection con;
    @FXML
    void initialize() {
        assert match != null : "fx:id=\"match\" was not injected: check your FXML file 'Page8View.fxml'.";
        assert overs != null : "fx:id=\"overs\" was not injected: check your FXML file 'Page8View.fxml'.";
        assert date != null : "fx:id=\"date\" was not injected: check your FXML file 'Page8View.fxml'.";
        assert matchloc != null : "fx:id=\"matchloc\" was not injected: check your FXML file 'Page8View.fxml'.";
        assert ball != null : "fx:id=\"ball\" was not injected: check your FXML file 'Page8View.fxml'.";
        assert toss != null : "fx:id=\"toss\" was not injected: check your FXML file 'Page8View.fxml'.";
        assert offtobat != null : "fx:id=\"offtobat\" was not injected: check your FXML file 'Page8View.fxml'.";
        assert combobox != null : "fx:id=\"combobox\" was not injected: check your FXML file 'Page8View.fxml'.";

        ArrayList<String> ary=new ArrayList<String>(Arrays.asList("india vs pakisthan"));
        combobox.getItems().addAll(ary);

    }
}


//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml"));
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/
