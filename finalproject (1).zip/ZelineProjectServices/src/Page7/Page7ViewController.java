package Page7;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

public class Page7ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void close(ActionEvent event) {
    System.exit(1);
    }

    @FXML
    void info(ActionEvent event) throws IOException{
        javafx.scene.Parent root= FXMLLoader.load(getClass().getResource("/Page8/Page8Vieww.fxml"));
        //OR
        //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        javafx.stage.Stage stage=new javafx.stage.Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void live(ActionEvent event) throws IOException {
        javafx.scene.Parent root= FXMLLoader.load(getClass().getResource("/Page9/Page9View.fxml"));
        //OR
        //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        javafx.stage.Stage stage=new javafx.stage.Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void scorecard(ActionEvent event) throws IOException {
        javafx.scene.Parent root= FXMLLoader.load(getClass().getResource("/Pagez10/finalPage.fxml"));
        //OR
        //Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
        javafx.scene.Scene scene = new javafx.scene.Scene(root);
        javafx.stage.Stage stage=new javafx.stage.Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void initialize() {

    }
}



//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml")); 
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/