package Page8;

import java.net.URL;
import java.util.ResourceBundle;

import Dependies_Zeline.MySQL_Connector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;

public class Page8ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField team;

    @FXML
    private TextField match;

    @FXML
    private TextField overs;

    @FXML
    private TextField dateandtime;

    @FXML
    private TextField venue;

    @FXML
    private TextField ball;

    @FXML
    private TextField toss;

    @FXML
    private TextField offtobat;

    @FXML
    void close(ActionEvent event) {
        System.exit(0);
    }


    @FXML
    void submit(ActionEvent event) {
        java.sql.Connection con;
        con=MySQL_Connector.getConnection();
        java.sql.PreparedStatement pst;

        try {
            pst=con.prepareStatement("insert into info values(?,?,?,?,?,?,?,?)");
            pst.setString(1, team.getText());
            pst.setString(2, match.getText());
            pst.setString(3, overs.getText());
            pst.setString(4, dateandtime.getText());
            pst.setString(5, venue.getText());
            pst.setString(6, ball.getText());
            pst.setString(7, toss.getText());
            pst.setString(8, offtobat.getText());
            pst.executeUpdate();
            showMsg("Saved!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void showMsg(String msg) {
        Alert alert=new Alert(AlertType.INFORMATION);
        alert.setTitle("Admin Panel Says:");
        alert.setHeaderText("Match Uploaded");
        alert.setContentText(msg);
        alert.showAndWait();

    }

    @FXML
    void initialize() {
        assert team != null : "fx:id=\"team\" was not injected: check your FXML file 'page8Vieww.fxml'.";
        assert match != null : "fx:id=\"match\" was not injected: check your FXML file 'page8Vieww.fxml'.";
        assert overs != null : "fx:id=\"overs\" was not injected: check your FXML file 'page8Vieww.fxml'.";
        assert dateandtime != null : "fx:id=\"dateandtime\" was not injected: check your FXML file 'page8Vieww.fxml'.";
        assert venue != null : "fx:id=\"venue\" was not injected: check your FXML file 'page8Vieww.fxml'.";
        assert ball != null : "fx:id=\"ball\" was not injected: check your FXML file 'page8Vieww.fxml'.";
        assert offtobat != null : "fx:id=\"offtobat\" was not injected: check your FXML file 'page8Vieww.fxml'.";
        assert toss != null : "fx:id=\"toss\" was not injected: check your FXML file 'page8Vieww.fxml'.";

    }
}







//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml"));
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml"));
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/
//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml")); 
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/