package Page6;


import java.net.URL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

import Dependies_Zeline.MySQL_Connector;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;

public class Page6ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label lab3;

    @FXML
    private Label lab4;

    @FXML
    private Label lab5;

    @FXML
    private Label lab6;

    @FXML
    private Label lab7;

    @FXML
    private Label lab8;

    @FXML
    private Label lab9;

    @FXML
    private Label lab2;

    @FXML
    private Label lab1;

    @FXML
    private Label lab10;

    @FXML
    private ComboBox<String> combobox;

    @FXML
    private Label lab31;

    @FXML
    private Label lab41;

    @FXML
    private Label lab51;

    @FXML
    private Label lab21;

    @FXML
    private Label lab11;


    @FXML
    private Label bat1;

    @FXML
    private Label bat2;

    @FXML
    private Label bat3;

    @FXML
    private Label bat4;

    @FXML
    private Label bat5;

    @FXML
    private Label bat6;

    @FXML
    private Label bat7;

    @FXML
    private Label bat8;

    @FXML
    private Label bat9;

    @FXML
    private Label bat10;

    @FXML
    private Label bol1;

    @FXML
    private Label bol2;

    @FXML
    private Label bol3;

    @FXML
    private Label bol4;

    @FXML
    private Label bol5;


    @FXML
    void show(ActionEvent event) {

        String teamfx=combobox.getSelectionModel().getSelectedItem();
        java.sql.Connection con;
        con=MySQL_Connector.getConnection();
        java.sql.PreparedStatement pst;
        System.out.println(teamfx);
        try {
            pst=con.prepareStatement(" SELECT * from scorecard");
            ResultSet res=pst.executeQuery();
            //pst.executeUpdate();
            boolean count=false;
            int i=1;
            while(res.next()|| i<=10) {
                count=true;

                String batsman= res.getString("batsman");
                String r=res.getString("r");
                String s4= res.getString("4s");
                String b=res.getString("b");
                String s6=res.getString("6s");
                String sr=res.getString("sr");
                String outt=res.getString("outt");
                String bowler=res.getString("bowler");
                String O=res.getString("op");
                String m=res.getString("m");
                String run=res.getString("run");
                String w=res.getString("w");
                String er=res.getString("er");

                if(i==1) {
                    System.out.println("inside a");
                    bat1.setText(batsman);
                    bol1.setText(bowler);
                    lab11.setText("   "+O+"            "+m+"         "+run+"         "+w+"        "+er);
                    lab1.setText("    "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==2) {
                    bat2.setText(batsman);
                    bol2.setText(bowler);
                    lab21.setText("   "+O+"            "+m+"         "+run+"         "+w+"        "+er);
                    lab2.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==3) {
                    bat3.setText(batsman);
                    bol3.setText(bowler);
                    lab31.setText("   "+O+"            "+m+"         "+run+"         "+w+"        "+er);
                    lab3.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==4) {
                    bat4.setText(batsman);
                    bol4.setText(bowler);
                    lab41.setText("   "+O+"            "+m+"         "+run+"         "+w+"        "+er);
                    lab4.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==5) {
                    bol5.setText("hello");
                    lab51.setText("   "+O+"            "+m+"         "+run+"         "+w+"        "+er);
                    bat5.setText(batsman);
                    lab5.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==6) {
                    bat6.setText(batsman);
                    lab6.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==7) {
                    bat7.setText(batsman);
                    lab7.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==8) {
                    bat8.setText(batsman);
                    lab8.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==9) {
                    bat9.setText(batsman);
                    lab9.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }
                if(i==10) {
                    bat10.setText(batsman);
                    lab10.setText("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                }


                System.out.println("   "+r+"            "+s4+"         "+b+"         "+s6+"        "+sr+"        "+outt);
                System.out.println("\n");
                System.out.println(bowler+" "+O+"            "+m+"         "+run+"         "+w+"        "+er);
                System.out.println(i);


                i++;
                //showMsg("Saved!");
            }
        }

        catch (Exception e) {
            showMsg("Team Not Found!");
            e.printStackTrace();


        }
    }
    void showMsg(String msg) {
        Alert alert=new Alert(AlertType.INFORMATION);
        alert.setTitle("Cricket Project:");
        alert.setHeaderText("Your details make:");
        alert.setContentText(msg);
        alert.showAndWait();
    }
    java.sql.Connection con;


    @FXML
    void initialize() {
        assert lab3 != null : "fx:id=\"lab3\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab4 != null : "fx:id=\"lab4\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab5 != null : "fx:id=\"lab5\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab6 != null : "fx:id=\"lab6\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab7 != null : "fx:id=\"lab7\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab8 != null : "fx:id=\"lab8\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab9 != null : "fx:id=\"lab9\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab2 != null : "fx:id=\"lab2\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab1 != null : "fx:id=\"lab1\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab10 != null : "fx:id=\"lab10\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert combobox != null : "fx:id=\"combobox\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab31 != null : "fx:id=\"lab31\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab41 != null : "fx:id=\"lab41\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab51 != null : "fx:id=\"lab51\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab21 != null : "fx:id=\"lab21\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert lab11 != null : "fx:id=\"lab11\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat1 != null : "fx:id=\"bat1\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat2 != null : "fx:id=\"bat2\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat3 != null : "fx:id=\"bat3\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat4 != null : "fx:id=\"bat4\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat5 != null : "fx:id=\"bat5\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat6 != null : "fx:id=\"bat6\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat7 != null : "fx:id=\"bat7\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat8 != null : "fx:id=\"bat8\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat9 != null : "fx:id=\"bat9\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bat10 != null : "fx:id=\"bat10\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bol1 != null : "fx:id=\"bol1\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bol2 != null : "fx:id=\"bol2\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bol3 != null : "fx:id=\"bol3\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bol4 != null : "fx:id=\"bol4\" was not injected: check your FXML file 'Page11View.fxml'.";
        assert bol5 != null : "fx:id=\"bol5\" was not injected: check your FXML file 'Page11View.fxml'.";


        ArrayList<String> ary=new ArrayList<String>(Arrays.asList("india vs pakisthan"));
        combobox.getItems().addAll(ary);

    }
}

//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml")); 
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/