

package Pagez10;

        import java.net.URL;
        import java.util.ArrayList;
        import java.util.Arrays;
        import java.util.ResourceBundle;

        import Dependies_Zeline.MySQL_Connector;
        import javafx.event.ActionEvent;
        import javafx.fxml.FXML;
        import javafx.scene.control.Alert;
        import javafx.scene.control.ComboBox;
        import javafx.scene.control.TextField;

public class Page10ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField batter;

    @FXML
    private TextField batterrun;

    @FXML
    private TextField batterball;

    @FXML
    private TextField batterfour;

    @FXML
    private TextField battersix;

    @FXML
    private TextField battersr;

    @FXML
    private TextField batterout;

    @FXML
    private TextField bollername;

    @FXML
    private TextField bollerop;

    @FXML
    private TextField bollerm;

    @FXML
    private TextField bollerw;

    @FXML
    private TextField bollerer;

    @FXML
    private ComboBox<String> combobox;

    @FXML
    private TextField bollerrun;

    @FXML
    void close(ActionEvent event) {
    System.exit(1);
    }

    @FXML
    void submit(ActionEvent event) {
        java.sql.Connection con;
        con= MySQL_Connector.getConnection();
        java.sql.PreparedStatement pst;

        try {
            String teamfx=combobox.getSelectionModel().getSelectedItem();
            pst=con.prepareStatement("insert into scorecard values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, teamfx);
            pst.setString(2, batter.getText());
            pst.setString(3, batterrun.getText());
            pst.setString(4, batterball.getText());
            pst.setString(5, batterfour.getText());
            pst.setString(6, battersix.getText());
            pst.setString(7, battersr.getText());
            pst.setString(8, batterout.getText());
            pst.setString(9, bollername.getText());
            pst.setString(10, bollerop.getText());
            pst.setString(11,bollerm.getText());
            pst.setString(12,bollerrun.getText());
            pst.setString(13,bollerw.getText());
            pst.setString(14,bollerer.getText());

            pst.executeUpdate();
            showMsg("Saved!");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    void showMsg(String msg) {
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Admin Panel Says:");
        alert.setHeaderText("Match Uploaded");
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    void initialize() {
        assert batter != null : "fx:id=\"batter\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert batterrun != null : "fx:id=\"batterrun\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert batterball != null : "fx:id=\"batterball\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert batterfour != null : "fx:id=\"batterfour\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert battersix != null : "fx:id=\"battersix\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert battersr != null : "fx:id=\"battersr\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert batterout != null : "fx:id=\"batterout\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert bollername != null : "fx:id=\"bollername\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert bollerop != null : "fx:id=\"bollerop\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert bollerm != null : "fx:id=\"bollerm\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert bollerw != null : "fx:id=\"bollerw\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert bollerer != null : "fx:id=\"bollerer\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert combobox != null : "fx:id=\"combobox\" was not injected: check your FXML file 'finalPage.fxml'.";
        assert bollerrun != null : "fx:id=\"bollerrun\" was not injected: check your FXML file 'finalPage.fxml'.";
        ArrayList<String> ary=new ArrayList<String>(Arrays.asList("india vs pakisthan"));
        combobox.getItems().addAll(ary);

    }
}

//CONNECTORS--**
/*javafx.scene.Parent root=FXMLLoader.load(getClass().getResource("/Home/HomeView.fxml")); 
	//OR
	//Parent root=FXMLLoader.load(getClass().getClassLoader().getResource("marks/card/MarksCard.fxml")); 
	javafx.scene.Scene scene = new javafx.scene.Scene(root);
	javafx.stage.Stage stage=new javafx.stage.Stage();
	stage.setScene(scene);
	stage.show();
}*/